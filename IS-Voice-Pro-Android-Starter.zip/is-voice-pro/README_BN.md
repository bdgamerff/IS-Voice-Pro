# IS Voice Pro — Android starter project

এটি Kotlin-ভিত্তিক Android Studio প্রজেক্ট। এতে রয়েছে:
- Voice recording (AAC/M4A)
- Recorded audio playback speed/pitch demo (normal, slow/deep, fast/high)
- ফোন থেকে audio file যোগ করে Soundboard playback
- Unlimited Text-to-Speech app-side (long text split into supported chunks), installed offline voice selection, speed/pitch controls
- Display-over-other-apps অনুমতি দিয়ে floating bubble

## APK বানানোর নিয়ম
1. কম্পিউটারে Android Studio (সাম্প্রতিক stable) ইনস্টল করুন।
2. ZIP extract করে Android Studio থেকে `is-voice-pro` ফোল্ডার Open করুন।
3. Gradle sync শেষ হলে Build → Build Bundle(s) / APK(s) → Build APK(s) চাপুন।
4. APK পাবেন `app/build/outputs/apk/debug/app-debug.apk` ফাইলে।

## Text-to-Speech ও Custom Voice
- অ্যাপে আলাদা character/paywall limit নেই; Android TTS engine-এর utterance queue ব্যবহার করে দীর্ঘ লেখা ভাগে ভাগে পড়ানো হয়।
- উপলব্ধ ভাষা/কণ্ঠ ফোনের TTS engine ও ইনস্টল করা voice data-এর ওপর নির্ভরশীল।
- নিজের বা অন্য কারও অনুমতিপ্রাপ্ত অডিও Soundboard-এ যোগ করা যায়। এটি AI voice cloning নয়; প্রকৃত voice cloning-এর জন্য সম্মতিসহ আলাদা voice model/service প্রয়োজন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি IS VOICE FF-এর মূল APK-এর কোডের কপি নয়; নিজস্ব implementation ও UI starter।
- মূল অ্যাপের DEX-এ Root/Shizuku-ভিত্তিক experimental audio injection এবং server/clone voice সংক্রান্ত অংশের চিহ্ন পাওয়া যায়। সেগুলো এখানে পুনরুৎপাদন করা হয়নি।
- Android-এর সাধারণ third-party app অন্য গেমের microphone input সরাসরি replace করতে পারে না। Floating bubble কেবল overlay control; এটি game mic injection করে না।
- বর্তমান pitch demo MediaPlayer playback speed ও pitch একসঙ্গে বদলায়; উন্নত pitch-preserving voice changer নয়।
- Cloud voice cloning-এর জন্য বৈধ API, API key, server এবং privacy/consent ব্যবস্থা প্রয়োজন; এই starter-এ কোনো অজানা server endpoint বা key নেই।

## Package
`com.example.isvoicepro` — Play Store বা ব্যক্তিগত release-এর আগে নিজের application ID দিয়ে পরিবর্তন করুন।
