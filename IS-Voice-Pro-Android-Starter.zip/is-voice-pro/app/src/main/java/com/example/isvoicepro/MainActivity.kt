package com.example.isvoicepro

import android.Manifest
import androidx.activity.ComponentActivity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var root: LinearLayout
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var recordingFile: File? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val sounds = mutableListOf<Pair<String, Uri>>()
    private var ttsVoiceSpinner: Spinner? = null
    private var selectedTtsVoices: List<android.speech.tts.Voice> = emptyList()
    private var ttsPitch = 1.0f
    private var ttsSpeed = 1.0f

    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else toast("মাইক্রোফোন অনুমতি প্রয়োজন")
    }
    private val audioPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val name = displayName(uri) ?: "My sound ${sounds.size + 1}"
            sounds.add(name to uri)
            showSoundboard()
            toast("সাউন্ড যোগ হয়েছে")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildHome()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val engine = tts
            val result = engine?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine?.language = Locale.US
            }
            refreshTtsVoices()
        }
    }

    private fun refreshTtsVoices() {
        val engine = tts ?: return
        selectedTtsVoices = engine.voices
            ?.filter { it != null && !it.isNetworkConnectionRequired }
            ?.sortedWith(compareBy({ it.locale.displayName }, { it.name }))
            ?: emptyList()
        val labels = selectedTtsVoices.map { voice ->
            "${voice.locale.displayName} • ${voice.name} (Offline)"
        }.ifEmpty { listOf("ফোনের Default voice") }
        ttsVoiceSpinner?.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 18); setBackgroundColor(0xFF10101B.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply { text = "IS VOICE PRO"; textSize = 28f; setTextColor(-1); gravity = Gravity.CENTER; setPadding(0, 10, 0, 6) }
        val subtitle = TextView(this).apply { text = "Voice • Soundboard • Studio"; textSize = 14f; setTextColor(0xFFBDB8D8.toInt()); gravity = Gravity.CENTER; setPadding(0, 0, 0, 24) }
        content.addView(title); content.addView(subtitle)
        addMenu(content, "🎙  Voice Studio", "রেকর্ড, ভয়েস ইফেক্ট ও প্লেব্যাক") { showVoiceStudio() }
        addMenu(content, "🔊  Soundboard", "নিজের অডিও ফাইল যোগ করে চালান") { showSoundboard() }
        addMenu(content, "🗣  Text to Speech", "লেখা থেকে কণ্ঠ তৈরি করুন") { showTts() }
        addMenu(content, "🫧  Floating Overlay", "অন্যান্য অ্যাপের ওপর ছোট কন্ট্রোল") { enableOverlay() }
        addMenu(content, "⚙  Settings", "অনুমতি ও অ্যাপের তথ্য") { showSettings() }
        val note = TextView(this).apply { text = "নোট: এই অ্যাপ রেকর্ড করা অডিওতে স্থানীয় playback effect দেয়। অন্য গেমের লাইভ মাইক্রোফোন সরাসরি বদলানো Android-এ সাধারণ অ্যাপের জন্য সমর্থিত নয়।"; setTextColor(0xFFFFDDAA.toInt()); textSize = 12f; setPadding(8, 24, 8, 12) }
        content.addView(note)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun addMenu(parent: LinearLayout, heading: String, desc: String, action: () -> Unit) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16); setBackgroundColor(0xFF242238.toInt()); isClickable = true; isFocusable = true }
        val h = TextView(this).apply { text = heading; textSize = 18f; setTextColor(-1) }
        val d = TextView(this).apply { text = desc; textSize = 12f; setTextColor(0xFFC9C5D8.toInt()); setPadding(0, 6, 0, 0) }
        card.addView(h); card.addView(d)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
        parent.addView(card, lp); card.setOnClickListener { action() }
    }

    private fun page(title: String): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 20); setBackgroundColor(0xFF10101B.toInt()) }
        val back = Button(this).apply { text = "← Home"; setOnClickListener { stopPlayback(); buildHome() } }
        val heading = TextView(this).apply { text = title; textSize = 23f; setTextColor(-1); setPadding(0, 14, 0, 20) }
        box.addView(back); box.addView(heading); root = box; setContentView(box); return box
    }

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }
    private fun addText(parent: LinearLayout, text: String): TextView = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(-1); setPadding(2, 8, 2, 8); parent.addView(this) }

    private fun showVoiceStudio() {
        val p = page("Voice Studio")
        addText(p, "১. মাইক্রোফোনে নিজের ভয়েস রেকর্ড করুন")
        addButton(p, "● Start recording") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
            else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        addButton(p, "■ Stop recording") { stopRecording() }
        addText(p, "২. রেকর্ড করা ভয়েসে Playback Effect")
        addButton(p, "Normal voice ▶") { playRecording(1.0f) }
        addButton(p, "Slow / Deep ▶") { playRecording(0.75f) }
        addButton(p, "Fast / High ▶") { playRecording(1.25f) }
        addButton(p, "Stop playback") { stopPlayback() }
        addText(p, "ইফেক্টগুলো প্লেব্যাকের গতি ও পিচ একসঙ্গে বদলায়; এটি studio-grade pitch shifter নয়।")
    }

    private fun startRecording() {
        try {
            stopRecording()
            val dir = File(getExternalFilesDir(null), "recordings").apply { mkdirs() }
            recordingFile = File(dir, "voice_${System.currentTimeMillis()}.m4a")
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            recorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(recordingFile!!.absolutePath)
                prepare(); start()
            }
            toast("রেকর্ডিং শুরু হয়েছে")
        } catch (e: Exception) { toast("রেকর্ডিং শুরু হয়নি: ${e.localizedMessage}"); stopRecording() }
    }

    private fun stopRecording() {
        try { recorder?.stop() } catch (_: Exception) { }
        recorder?.release(); recorder = null
        if (recordingFile?.exists() == true) toast("সেভ হয়েছে: ${recordingFile!!.name}")
    }

    private fun playRecording(speed: Float) {
        val file = recordingFile
        if (file == null || !file.exists()) { toast("আগে একটি ভয়েস রেকর্ড করুন"); return }
        try {
            stopPlayback()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath); prepare()
                if (Build.VERSION.SDK_INT >= 23) playbackParams = PlaybackParams().setSpeed(speed).setPitch(speed)
                start(); setOnCompletionListener { stopPlayback() }
            }
        } catch (e: Exception) { toast("অডিও চালানো যায়নি: ${e.localizedMessage}") }
    }

    private fun showSoundboard() {
        val p = page("Soundboard")
        addText(p, "ফোন থেকে WAV, MP3, M4A বা OGG ফাইল যোগ করুন।")
        addButton(p, "+ Add sound from phone") { audioPicker.launch(arrayOf("audio/*")) }
        if (sounds.isEmpty()) addText(p, "এখনও কোনো সাউন্ড যোগ করা হয়নি।")
        sounds.forEachIndexed { index, item ->
            addButton(p, "▶ ${item.first}") { playUri(item.second) }
            addButton(p, "✕ Remove ${item.first}") { sounds.removeAt(index); showSoundboard() }
        }
        addButton(p, "Stop sound") { stopPlayback() }
    }

    private fun playUri(uri: Uri) {
        try { stopPlayback(); player = MediaPlayer().apply { setDataSource(this@MainActivity, uri); prepare(); start(); setOnCompletionListener { stopPlayback() } } }
        catch (e: Exception) { toast("সাউন্ড চালানো যায়নি: ${e.localizedMessage}") }
    }
    private fun stopPlayback() { try { player?.stop() } catch (_: Exception) { }; player?.release(); player = null }

    private fun showTts() {
        val p = page("Unlimited Text to Speech")
        addText(p, "বাংলা বা ইংরেজি লিখুন। অ্যাপের নিজস্ব character limit নেই; দীর্ঘ লেখা ছোট অংশে ভাগ করে পড়ানো হবে।")
        val input = EditText(this).apply {
            hint = "এখানে যত ইচ্ছা লেখা লিখুন..."
            minLines = 7
            gravity = Gravity.TOP
            setTextColor(-1)
            setHintTextColor(0xFFAAAAAA.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF242238.toInt())
        }
        p.addView(input, LinearLayout.LayoutParams(-1, -2))

        addText(p, "Voice / ভাষা (ফোনে ইনস্টল করা TTS voice)")
        val spinner = Spinner(this)
        ttsVoiceSpinner = spinner
        p.addView(spinner, LinearLayout.LayoutParams(-1, -2))
        if (ttsReady) refreshTtsVoices()
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedTtsVoices.getOrNull(position)?.let { voice ->
                    try { tts?.voice = voice } catch (_: Exception) { }
                }
            }
        }

        addText(p, "Voice speed")
        val speedLabel = addText(p, "1.0x")
        val speed = SeekBar(this).apply { max = 200; progress = 100 }
        p.addView(speed, LinearLayout.LayoutParams(-1, -2))
        speed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsSpeed = (0.5f + progress / 100f).coerceIn(0.5f, 2.5f)
                speedLabel.text = String.format(Locale.US, "%.1fx", ttsSpeed)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        addText(p, "Voice pitch")
        val pitchLabel = addText(p, "1.0")
        val pitch = SeekBar(this).apply { max = 200; progress = 100 }
        p.addView(pitch, LinearLayout.LayoutParams(-1, -2))
        pitch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ttsPitch = (0.5f + progress / 100f).coerceIn(0.5f, 2.5f)
                pitchLabel.text = String.format(Locale.US, "%.1f", ttsPitch)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        addButton(p, "▶ Convert & Speak (Unlimited text)") {
            val text = input.text.toString().trim()
            if (text.isEmpty()) toast("কিছু লিখুন")
            else if (!ttsReady) toast("TTS engine প্রস্তুত হচ্ছে")
            else {
                val engine = tts
                engine?.setSpeechRate(ttsSpeed)
                engine?.setPitch(ttsPitch)
                val chunks = splitForTts(text, 3000)
                chunks.forEachIndexed { index, chunk ->
                    engine?.speak(chunk, if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "is_voice_tts_$index")
                }
                toast("${chunks.size}টি অংশে ভয়েস পড়ানো হচ্ছে")
            }
        }
        addButton(p, "■ Stop speech") { tts?.stop() }
        addButton(p, "↻ Refresh installed voices") { refreshTtsVoices(); toast("ফোনের TTS voice তালিকা আপডেট হয়েছে") }
        addText(p, "Custom voice: ফোনে ইনস্টল করা TTS voice বেছে নিতে পারবেন। নিজের বা অন্য কারও অনুমতিপ্রাপ্ত রেকর্ডিং Soundboard-এ যোগ করা যাবে; রেকর্ডিং নিজে থেকে AI voice clone হয় না।")
        addButton(p, "+ Add custom voice recording to Soundboard") { audioPicker.launch(arrayOf("audio/*")) }
        addText(p, "অফলাইনে ব্যবহার করতে ফোনের Text-to-Speech সেটিংসে offline voice data ইনস্টল করুন। বাংলা voice না থাকলে বাংলা voice data যোগ করতে হবে।")
    }

    private fun splitForTts(text: String, maxChars: Int): List<String> {
        val result = mutableListOf<String>()
        var remaining = text.trim()
        while (remaining.isNotEmpty()) {
            if (remaining.length <= maxChars) {
                result.add(remaining)
                break
            }
            var cut = remaining.lastIndexOf(' ', maxChars)
            if (cut < maxChars / 2) cut = maxChars
            result.add(remaining.substring(0, cut).trim())
            remaining = remaining.substring(cut).trim()
        }
        return result.filter { it.isNotEmpty() }
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("IS Voice Pro-এর জন্য Display over other apps অনুমতি দিন")
        } else { startService(Intent(this, OverlayService::class.java)); toast("Floating control চালু হয়েছে") }
    }

    private fun showSettings() {
        val p = page("Settings")
        addButton(p, "Overlay permission") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        addButton(p, "Microphone permission") { audioPermission.launch(Manifest.permission.RECORD_AUDIO) }
        addButton(p, "Stop floating control") { stopService(Intent(this, OverlayService::class.java)) }
        addText(p, "IS Voice Pro 1.0 • Audio processing stays on your device.")
    }

    private fun displayName(uri: Uri): String? = contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() { stopRecording(); stopPlayback(); tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
