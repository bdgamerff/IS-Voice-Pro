package com.example.isvoicepro

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble != null) return START_STICKY
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        bubble = TextView(this).apply {
            text = "IS\nVOICE"; textSize = 11f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xFF7048D8.toInt()); setPadding(12, 12, 12, 12)
            setOnClickListener { Toast.makeText(this@OverlayService, "IS Voice Pro চালু আছে — লাইভ গেম মাইক্রোফোন পরিবর্তন সমর্থিত নয়", Toast.LENGTH_LONG).show() }
            setOnLongClickListener { stopSelf(); true }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(76, 76, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = 18; y = 220
        }
        try { windowManager?.addView(bubble, params) } catch (_: Exception) { stopSelf() }
        return START_STICKY
    }

    override fun onDestroy() { try { if (bubble != null) windowManager?.removeView(bubble) } catch (_: Exception) { }; bubble = null; windowManager = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
